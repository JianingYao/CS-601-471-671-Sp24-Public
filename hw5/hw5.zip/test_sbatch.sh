#!/bin/bash

#SBATCH -N 1

#SBATCH -n 1

#SBATCH --gres=gpu:1

#SBATCH --partition=mig_class

#SBATCH

sleep 300